let users = [
    {
        "_id": "5ba22ccb30980557aa53f722",
        "name": "test1",
        "email": "test1.raogmail.com",
        "password": "$2a$08$HtqmsnLk71v.YoBh/XFlOu29e.Ygl2/wS6/2v6I7cyX4.DTAtyEWW",
        "__v": 0
    },
    {
        "_id": "5ba22ccb30980557aa53f723",
        "name": "test2",
        "email": "test2.raogmail.com",
        "password": "$2a$08$HtqmsnLk71v.YoBh/XFlOu29e.Ygl2/wS6/2v6I7cyX4.DTAtyEWW",
        "__v": 0
    }
]

module.exports = {
    users
}